class MissionGenerator: pass
