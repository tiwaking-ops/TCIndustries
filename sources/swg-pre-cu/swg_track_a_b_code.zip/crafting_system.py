class CraftingSystem: pass
