class GuildSystem: pass
