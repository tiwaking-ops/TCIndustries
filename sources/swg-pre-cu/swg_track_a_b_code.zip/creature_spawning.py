class CreatureSpawner: pass
