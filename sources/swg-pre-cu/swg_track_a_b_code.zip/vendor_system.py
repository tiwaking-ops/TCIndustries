class Vendor: pass
