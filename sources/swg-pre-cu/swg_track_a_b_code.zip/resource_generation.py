class ResourceGenerator: pass
