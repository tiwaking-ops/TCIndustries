class FactionSystem: pass
