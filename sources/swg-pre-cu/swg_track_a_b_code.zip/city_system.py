class CitySystem: pass
