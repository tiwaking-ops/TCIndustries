class EconomyLedger: pass
