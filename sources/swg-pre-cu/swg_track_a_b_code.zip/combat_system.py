class CombatSystem: pass
